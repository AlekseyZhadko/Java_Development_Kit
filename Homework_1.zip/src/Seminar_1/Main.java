package Seminar_1;

public class Main {
    public static void main(String[] args) {
        new GameWindow();
        System.out.println("Method main() is over");


    }
}