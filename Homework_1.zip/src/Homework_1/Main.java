package Homework_1;

import Seminar_1.GameWindow;

public class Main {
    public static void main(String[] args) {
        new ServerWindow();
    }
}